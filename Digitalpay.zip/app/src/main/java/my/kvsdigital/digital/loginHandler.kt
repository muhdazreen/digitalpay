package my.kvsdigital.digital
//interact with server
class LoginHandler {
    fun login(username: String, pin: Int) : Boolean {
        if ((username.equals("test")) && (pin == 123456)) {
            return true
        }
        return false
    }

    fun signUp(email: String, username: String, pin: Int) : Boolean {
        return false
    }
}
