package my.kvsdigital.digital

import android.app.ProgressDialog
import android.content.Intent
import android.os.AsyncTask
import android.support.v7.app.AppCompatActivity
import android.os.Bundle
import android.os.Handler
import android.util.Log
import android.view.View
import android.widget.Toast
import kotlinx.android.synthetic.main.activity_splash.*
import java.io.IOException
import java.net.InetSocketAddress
import java.net.Socket

internal class PingCheck(private val mconsumer : Consumer) :  AsyncTask<Void, Void, Boolean>() {
    interface  Consumer {
        fun accept(internet : Boolean?)
    }

    init {
        execute()
    }

    override fun doInBackground(vararg voids: Void) : Boolean? {
        try {
            val sock = Socket()
            sock.connect(InetSocketAddress("8.8.8.8", 53), 1500)
            sock.close()
            return true
        } catch (e : IOException) {
            Log.d("Exception: ", e.toString())
            return false
        }
    }

    override fun onPostExecute(internet: Boolean?) {
        mconsumer.accept(internet)
    }
}

class Splash : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_splash)

        PingCheck( object : PingCheck.Consumer {
            override fun accept(internet: Boolean?) {
                Log.d("Internet", internet.toString())
                if (internet == true) {
                    progressBar.progress.inc()
                    callLogin()
                }
                else { Toast.makeText(this@Splash, "No internet connection", Toast.LENGTH_SHORT).show() }
            }
        })
    }

    fun callLogin() {
        Handler().postDelayed({
            startActivity(Intent(this, Login::class.java))
            finish()
        }, 4000)
    }
}