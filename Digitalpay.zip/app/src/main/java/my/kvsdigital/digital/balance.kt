package my.kvsdigital.digital

import android.app.Fragment
import android.support.v7.app.AppCompatActivity
import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import kotlinx.android.synthetic.main.fragment_balance.*

class balance :  Fragment() {
    companion object {
        fun newInstance(): balance {
            return balance()
        }
    }

    override fun onCreateView(inflater: LayoutInflater?, container: ViewGroup?, savedInstanceState: Bundle?): View? {
        return inflater?.inflate(R.layout.fragment_balance, container, false)
    }

    /*
    fun accBalance(accNo : Int) : Float {
        val accTotalbalance : FloatArray = floatArrayOf(10.8F, 20.4F, 33.6F)
        return accTotalbalance[accNo]
    }
    */
}
