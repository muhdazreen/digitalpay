package my.kvsdigital.digital

import android.content.Intent
import android.support.v7.app.AppCompatActivity
import android.os.Bundle
import android.view.KeyEvent
import android.view.View
import android.widget.Toast
import kotlinx.android.synthetic.main.activity_login.*

class Login : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_login)
        button.setOnClickListener {
            val uname = editText.text.toString()
            val upin = editText2.text.toString().toInt()

            val lgnhn = LoginHandler()
            if (lgnhn.login(uname, upin)) {
                val intent = Intent(this@Login, Main::class.java)
                startActivity(intent)
                finish()
            }

            else {
                Toast.makeText(this@Login, "Credential failed!!! Please Try Again", Toast.LENGTH_SHORT).show()
            }
        }
        editText2.setOnKeyListener( View.OnKeyListener { _, keyCode, event ->
           if (keyCode == KeyEvent.KEYCODE_ENTER && event.action == KeyEvent.ACTION_UP) {
               button.callOnClick()
               return@OnKeyListener true
           }
            false
        })

        tvbutton.setOnClickListener {
            val goSignUp = Intent( this@Login, signUp::class.java)
            startActivity(goSignUp)
        }
    }
}
